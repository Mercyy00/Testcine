$exclude = @('node_modules', '.next', '.next-test', 'test-results', 'temp_found.json', 'vivarium.zip')
$items = Get-ChildItem -Path . | Where-Object { $exclude -notcontains $_.Name }
$dest = Join-Path $PWD "vivarium.zip"
if (Test-Path $dest) { Remove-Item $dest -Force }
Compress-Archive -Path $items.FullName -DestinationPath $dest -Force
Write-Host "ZIP created successfully at $dest"
$zip = Get-Item $dest
Write-Host "Size: $([math]::round($zip.Length / 1MB, 2)) MB"
